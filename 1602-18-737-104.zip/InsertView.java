import java.awt.*;

import java.awt.event.*;
import java.sql.*;
public class ViewVideo extends Frame
{
Button viewbtn;
TextField gentxt;
Choice usid, vid;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public ViewVideo()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadUsers()
{
try
{
 rs = statement.executeQuery("SELECT * FROM users");
 while (rs.next())
 {
usid.add(rs.getString("USID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}

}

private void loadVideos()
{
try
{
 rs = statement.executeQuery("SELECT * FROM videos");
 while (rs.next())
 {
vid.add(rs.getString("VID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}

}

public void buildGUI()
{ usid = new Choice();
loadUsers();

vid = new Choice();
loadVideos();

   
//Handle Reserve Button
viewbtn = new Button("Submit");
viewbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
 Statement statement = connection.createStatement();
 //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";  
 String query= "INSERT INTO views VALUES(" + usid.getSelectedItem() + ", " + vid.getSelectedItem() + ",'" + gentxt.getText() + "')";
 int i = statement.executeUpdate(query);
 errtxt.append("\nInserted " + i + " rows successfully");
}
catch (SQLException insertException)
{
 displaySQLErrors(insertException);
}
}
});


gentxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(3, 2));
first.add(new Label("User ID:"));
first.add(usid);
first.add(new Label("Video ID:"));
first.add(vid);
first.add(new Label("Genuineness:"));
first.add(gentxt);


Panel second = new Panel(new GridLayout(1, 1));
second.add(viewbtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("Insert View");
setSize(500, 600);
setLayout(new FlowLayout());
setVisible(true);

}

private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
ViewVideo vv = new ViewVideo();

vv.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

vv.buildGUI();
}
}