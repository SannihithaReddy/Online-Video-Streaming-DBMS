import java.awt.*;

import java.awt.event.*;
import java.sql.*;
public class UploadVideo extends Frame
{
Button uplbtn;
TextField sintxt;
Choice aid, vid;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public UploadVideo()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadVideos()
{
try
{
 rs = statement.executeQuery("SELECT * FROM videos");
 while (rs.next())
 {
vid.add(rs.getString("VID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}

}

private void loadAdmin()
{
try
{
 rs = statement.executeQuery("SELECT * FROM admin");
 while (rs.next())
 {
aid.add(rs.getString("AID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}

}

public void buildGUI()
{ vid = new Choice();
loadVideos();

aid = new Choice();
loadAdmin();

   
//Handle Reserve Button
uplbtn = new Button("Upload");
uplbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
 Statement statement = connection.createStatement();
 
 String query= "INSERT INTO uploads VALUES(" + vid.getSelectedItem() + ", " + aid.getSelectedItem() + ",'" + sintxt.getText() + "')";
 int i = statement.executeUpdate(query);
 errtxt.append("\nInserted " + i + " rows successfully");
}
catch (SQLException insertException)
{
 displaySQLErrors(insertException);
}
}
});


sintxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(3, 2));
first.add(new Label("Video ID:"));
first.add(vid);
first.add(new Label("Admin ID:"));
first.add(aid);
first.add(new Label("Since:"));
first.add(sintxt);


Panel second = new Panel(new GridLayout(1, 1));
second.add(uplbtn);

Panel third = new Panel();
third.add(errtxt);
           
add(first);
add(second);
add(third);
   
setTitle("Insert Upload ");
setSize(500, 600);
setLayout(new FlowLayout());
setVisible(true);

}
 
private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
UploadVideo vv = new UploadVideo();

vv.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

vv.buildGUI();
}
}