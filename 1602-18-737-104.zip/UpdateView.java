import java.awt.event.*;
import java.sql.*;
public class UpdateView extends Frame
{
Button updvibtn;
List USIDList;
TextField usidtxt, vidtxt,gentxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public UpdateView()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
     }
private void loadUsers()
{  
try
{
 rs = statement.executeQuery("SELECT USID FROM users");
 while (rs.next())
 {
USIDList.add(rs.getString("USID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   USIDList = new List(10);
loadUsers();
add(USIDList);

//When a list item is selected populate the text fields
USIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM users where USID ="+USIDList.getSelectedItem());
rs.next();
usidtxt.setText(rs.getString("USID"));
vidtxt.setText(rs.getString("VIDEO"));
gentxt.setText(rs.getString("GENUINENESS"));

}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Update Sailor Button
upduserbtn = new Button("Update ");
upduserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("UPDATE views "
+ "SET vid=" + vidtxt.getText() + ", "
+ "genuineness='" + pwdtxt.getText() + "' , "
+ " WHERE usid = "
+ USIDList.getSelectedItem());
errtxt.append("\nUpdated " + i + " rows successfully");
USIDList.removeAll();
loadUsers();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

usidtxt = new TextField(15);
usidtxt.setEditable(false);
vidtxt = new TextField(15);
gentxt = new TextField(15);


errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("USID:"));
first.add(usidtxt);
first.add(new Label("VID:"));
first.add(vidtxt);
first.add(new Label("Genuineness:"));
first.add(gentxt);


Panel second = new Panel(new GridLayout(4, 1));
second.add(updvibtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("UPDATE VIEW");
setSize(500, 600);
setLayout(new FlowLayout());
setVisible(true);

}



private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}

public static void main(String[] args)
{
UpdateView upvi = new UpdateView();

upvi.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

upvi.buildGUI();
}
}
