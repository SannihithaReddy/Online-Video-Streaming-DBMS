import java.awt.*;

import java.awt.event.*;

import java.sql.*;

public class AddVideo extends Frame
{
Button adduserbtn;
TextField vidtxt, toptxt, numvtxt, durtxt;
TextArea errtxt;
Connection connection;
Statement statement;
public AddVideo()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }


public void buildGUI()
{

adduserbtn = new Button("Insert");
adduserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
 
 String query= "INSERT INTO videos VALUES(" + vidtxt.getText() + ", "  + durtxt.getText() +"," +"'"+ toptxt.getText() +"'"+ "," + numvtxt.getText() + ")";
 int i = statement.executeUpdate(query);
//  System.out.print("jgig\nbj");
 errtxt.append("\nInserted " + i + " rows successfully");
 //System.out.print("jgig\nbj");
}
catch (SQLException insertException)
{
 displaySQLErrors(insertException);
}
}
});


vidtxt = new TextField(15);
durtxt = new TextField(15);
toptxt = new TextField(15);
numvtxt = new TextField(15);


errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("Video ID:"));
first.add(vidtxt);
first.add(new Label("Duration:"));
first.add(durtxt);
first.add(new Label("Topic:"));
first.add(toptxt);
first.add(new Label("Views:"));
first.add(numvtxt);
first.setBounds(125,90,200,100);

Panel second = new Panel(new GridLayout(4, 1));
second.add(adduserbtn);
        second.setBounds(125,220,150,100);        

Panel third = new Panel();
third.add(errtxt);
third.setBounds(125,320,300,200);

setLayout(null);

add(first);
add(second);
add(third);
   
setTitle("INSERT VIDEO");
setSize(500, 600);
setVisible(true);


}


private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}

public static void main(String[] args)
{
AddVideo vid = new AddVideo();

vid.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

vid.buildGUI();

}

}