import java.awt.*;
 
import java.awt.event.*;
import java.sql.*;
public class DeleteUser extends Frame
{
Button dltuserbtn;
List USIDList;
TextField usidtxt, nametxt, pwdtxt, agetxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public DeleteUser()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadUsers()
{  
try
{
 rs = statement.executeQuery("SELECT * FROM users");
 while (rs.next())
 {
USIDList.add(rs.getString("USID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   USIDList = new List(10);
loadUsers();
add(USIDList);

//When a list item is selected populate the text fields
USIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM users");
while (rs.next())
{
if (rs.getString("USID").equals(USIDList.getSelectedItem()))
break;
}
if (!rs.isAfterLast())
{
usidtxt.setText(rs.getString("USID"));
nametxt.setText(rs.getString("NAME"));
pwdtxt.setText(rs.getString("PASSWORD"));
agetxt.setText(rs.getString("AGE"));
}
}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Delete User Button
dltuserbtn = new Button("Delete");
dltuserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("DELETE FROM users WHERE USID = "
+ USIDList.getSelectedItem());
errtxt.append("\nDeleted " + i + " rows successfully");
usidtxt.setText(null);
nametxt.setText(null);
pwdtxt.setText(null);
agetxt.setText(null);
USIDList.removeAll();
loadUsers();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

usidtxt = new TextField(15);
nametxt = new TextField(15);
pwdtxt = new TextField(15);
agetxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("User ID:"));
first.add(usidtxt);
first.add(new Label("Name:"));
first.add(nametxt);
first.add(new Label("Password:"));
first.add(pwdtxt);
first.add(new Label("Age:"));
first.add(agetxt);

Panel second = new Panel(new GridLayout(4, 1));
second.add(dltuserbtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("DELETE USER");
setSize(450, 600);
setLayout(new FlowLayout());
setVisible(true);

}





private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
DeleteUser delu = new DeleteUser();

delu.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

delu.buildGUI();
}
}