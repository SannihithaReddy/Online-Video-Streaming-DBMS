import java.awt.*;

import java.awt.event.*;
import java.sql.*;
public class DeleteVideo extends Frame
{
Button dltvidbtn;
List VIDList;
TextField vidtxt, durtxt, toptxt, numtxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public DeleteVideo()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadVideos()
{  
try
{
 rs = statement.executeQuery("SELECT * FROM videos");
 while (rs.next())
 {
VIDList.add(rs.getString("VID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   VIDList = new List(10);
loadVideos();
add(VIDList);

//When a list item is selected populate the text fields
VIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM videos");
while (rs.next())
{
if (rs.getString("VID").equals(VIDList.getSelectedItem()))
break;
}
if (!rs.isAfterLast())
{
vidtxt.setText(rs.getString("VID"));
durtxt.setText(rs.getString("DURATION"));
toptxt.setText(rs.getString("TOPIC"));
numtxt.setText(rs.getString("NUMVIEWS"));
}
}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Delete Sailor Button
dltvidbtn = new Button("Delet");
dltvidbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("DELETE FROM videos WHERE VID = "
+ VIDList.getSelectedItem());
errtxt.append("\nDeleted " + i + " rows successfully");
vidtxt.setText(null);
durtxt.setText(null);
toptxt.setText(null);
numtxt.setText(null);
VIDList.removeAll();
loadVideos();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

vidtxt = new TextField(15);
durtxt = new TextField(15);
toptxt = new TextField(15);
numtxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("Video ID:"));
first.add(vidtxt);
first.add(new Label("Duration:"));
first.add(durtxt);
first.add(new Label("Topic:"));
first.add(toptxt);
first.add(new Label("Views:"));
first.add(numtxt);

Panel second = new Panel(new GridLayout(4, 1));
second.add(dltvidbtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("DELETE VIDEO");
setSize(450, 600);
setLayout(new FlowLayout());
setVisible(true);

}





private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
DeleteVideo delv = new DeleteVideo();

delv.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

delv.buildGUI();
}
}