import java.awt.*;


import java.awt.event.*;

class OnlineVideoStream extends Frame 
{
 String msg = "";
 Label ll;
 InsertUser insu;
 UpdateUser updu;
 DeleteUser delu;
 InsertVideo insv;
 DeleteVideo delv;
 UpdateVideo updv;
 InsertView insvi;
 UpdateView updvi;
 DeleteView delvi;
 InsertUpload insupl;
 UpdateUpload updupl;
 DeleteUpload delupl;
 
 
 public OnlineVideoStream()
 {
ll = new Label();
ll.setAlignment(Label.CENTER);  
ll.setBounds(90,250,250,100);
ll.setText("Welcome to Online Video Streaming!");
add(ll);

// create menu bar and add it to frame
MenuBar mbar = new MenuBar();
setMenuBar(mbar);

// create the menu items and add it to Menu
Menu us = new Menu("Users");
MenuItem item1, item2, item3;
us.add(item1 = new MenuItem("Insert Users"));
us.add(item2 = new MenuItem("Update Users"));
us.add(item3 = new MenuItem("Delete Users"));
mbar.add(us);  

Menu vid = new Menu("Videos");
MenuItem item4, item5, item6;
vid.add(item4 = new MenuItem("Insert Videos"));
vid.add(item5 = new MenuItem("Update Videos"));
vid.add(item6 = new MenuItem("Delete Videos"));  
mbar.add(vid);

Menu view = new Menu("Views");
MenuItem item7, item8, item9;
view.add(item7 = new MenuItem("Insert Views"));
view.add(item8 = new MenuItem("Update Views"));
view.add(item9 = new MenuItem("Delete Views"));
mbar.add(view);

Menu upload = new Menu("Uploads");
MenuItem item10, item11, item12;
upload.add(item10 = new MenuItem("Insert Upload"));
upload.add(item11 = new MenuItem("Update Upload"));
upload.add(item12 = new MenuItem("Delete Upload"));
mbar.add(upload);

Menu admin = new Menu("Admins");
MenuItem item13, item14, item15;
admin.add(item10 = new MenuItem("Insert Admins"));
admin.add(item11 = new MenuItem("Update Admins"));
admin.add(item12 = new MenuItem("Delete Admins"));
mbar.add(admin);


//register listeners
item1.addActionListener(this);
item2.addActionListener(this);
item3.addActionListener(this);
item4.addActionListener(this);
item5.addActionListener(this);
item6.addActionListener(this);
item7.addActionListener(this);
item8.addActionListener(this);
item9.addActionListener(this);
item10.addActionListener(this);
item11.addActionListener(this);
item12.addActionListener(this);
item13.addActionListener(this);
item14.addActionListener(this);
item15.addActionListener(this);


// Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});

//Frame properties
setTitle("Online Video Streaming");
Color clr = new Color(200, 100, 150);
setBackground(clr);
setFont(new Font("SansSerif", Font.BOLD, 14));
setLayout(null);
setSize(500, 600);
setVisible(true);

 }  
 
 public void actionPerformed(ActionEvent ae)
 {

 String arg = ae.getActionCommand();
 if(arg.equals("Insert Users"))
 {
insu = new InsertUser();

addu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
addu.dispose();
}
});
addu.buildGUI();
          }

else if(arg.equals("Update Users"))
{
updu = new UpdateUser();
updu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
updu.dispose();
}
});
updu.buildGUI();
}

else if(arg.equals("Delete Users"))
{
delu = new DeleteUser();

delu.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
delu.dispose();
}
});
delu.buildGUI();
}

else if(arg.equals("Insert Videos"))
{
addv = new AddVideo();
addv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
addv.dispose();
}
});
addv.buildGUI();
}

else if(arg.equals("Update Videos"))
{
updv = new UpdateVideo();
// setVisible(false);
updv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
updv.dispose();
//setVisible(true);
}
});
updv.buildGUI();
}

else if(arg.equals("Delete Videos"))
{
delv = new DeleteVideo();
// setVisible(false);
delv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
{
delv.dispose();
//setVisible(true);
}
});
delv.buildGUI();
}
 
else if(arg.equals("Insert Views"))
{
insvi = new InsertView();
insvi.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
insvi.dispose();
}
});
insvi.buildGUI();
}
 
 else if(arg.equals("Delete Views"))
{
delvi = new DeleteView();
delv.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
delv.dispose();
}
});
delv.buildGUI();
}
 
else if(arg.equals("Insert Uploads"))
{
insupl = new UploadVideo();
insupl.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
insupl.dispose();
}
});
insupl.buildGUI();
}

else if(arg.equals("Delete Uploads"))
{
delupl = new DeleteUpload();
delupl.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e)
   {
delupl.dispose();
}
});
delupl.buildGUI();
}
 
 }
 public static void main(String ... args)
 {
new OnlineVideoStream();  
 }
}
 
