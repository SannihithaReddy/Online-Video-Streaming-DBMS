import java.awt.*;

import java.awt.GridLayout;
import java.awt.event.*;

import java.sql.*;

public class InsertUser extends Frame
{
Button adduserbtn;
TextField usidtxt, nametxt, pwdtxt, agetxt;
TextArea errtxt;
Connection connection;
Statement statement;
public InsertUser()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

public void buildGUI()
{

adduserbtn = new Button("Add User");
adduserbtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
 
 String query= "INSERT INTO users VALUES(" + usidtxt.getText() + ", " + "'" + nametxt.getText() + "'"+"," +"'"+ pwdtxt.getText() +"'"+ "," + agetxt.getText() + ")";
 int i = statement.executeUpdate(query);
//  System.out.print("jgig\nbj");
 errtxt.append("\nInserted " + i + " rows successfully");
//  System.out.print("jgig\nbj");
}
catch (SQLException insertException)
{
 displaySQLErrors(insertException);
}
}
});


usidtxt = new TextField(15);
nametxt = new TextField(15);
pwdtxt = new TextField(15);
agetxt = new TextField(15);


errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("User ID:"));
first.add(usidtxt);
first.add(new Label("Name:"));
first.add(nametxt);
first.add(new Label("Password"));
first.add(pwdtxt);
first.add(new Label("Age:"));
first.add(agetxt);
first.setBounds(125,90,200,100);

Panel second = new Panel(new GridLayout(4, 1));
second.add(adduserbtn);
        second.setBounds(125,220,150,100);        

Panel third = new Panel();
third.add(errtxt);
third.setBounds(125,320,300,200);

setLayout(null);

add(first);
add(second);
add(third);
   
setTitle("Registering new user");
setSize(500, 600);
setVisible(true);


}

private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}

public static void main(String[] args)
{
InsertUser user = new InsertUser();

user.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

user.buildGUI();

}
}