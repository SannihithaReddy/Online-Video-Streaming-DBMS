import java.awt.*;
 
import java.awt.event.*;
import java.sql.*;
public class DeleteView extends Frame
{
Button dltvibtn;
List USIDList;
TextField usidtxt, vidtxt,gentxt;
TextArea errtxt;
Connection connection;
Statement statement;
ResultSet rs;

public DeleteView()
{
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e)
{
System.err.println("Unable to find and load driver");
System.exit(1);
}
connectToDB();
}

public void connectToDB()
    {
try
{
 connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","msr","vasavi");
 statement = connection.createStatement();

}
catch (SQLException connectException)
{
 System.out.println(connectException.getMessage());
 System.out.println(connectException.getSQLState());
 System.out.println(connectException.getErrorCode());
 System.exit(1);
}
    }

private void loadUsers()
{  
try
{
 rs = statement.executeQuery("SELECT * FROM views");
 while (rs.next())
 {
USIDList.add(rs.getString("USID"));
 }
}
catch (SQLException e)
{
 displaySQLErrors(e);
}
}


public void buildGUI()
{
   USIDList = new List(10);
loadUsers();
add(USIDList);

//When a list item is selected populate the text fields
USIDList.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
try
{
rs = statement.executeQuery("SELECT * FROM views");
while (rs.next())
{
if (rs.getString("USID").equals(USIDList.getSelectedItem()))
break;
}
if (!rs.isAfterLast())
{
usidtxt.setText(rs.getString("USID"));
vidtxt.setText(rs.getString("VID"));
gentxt.setText(rs.getString("GENUINENESS"));
}
}
catch (SQLException selectException)
{
displaySQLErrors(selectException);
}
}
});

   
//Handle Delete User Button
dltvibtn = new Button("Delete");
dltvibtn.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
Statement statement = connection.createStatement();
int i = statement.executeUpdate("DELETE FROM views WHERE USID = "
+ USIDList.getSelectedItem());
errtxt.append("\nDeleted " + i + " rows successfully");
usidtxt.setText(null);
vidtxt.setText(null);
gentxt.setText(null);
USIDList.removeAll();
loadUsers();
}
catch (SQLException insertException)
{
displaySQLErrors(insertException);
}
}
});

usidtxt = new TextField(15);
vidtxt = new TextField(15);
gentxt = new TextField(15);

errtxt = new TextArea(10, 40);
errtxt.setEditable(false);

Panel first = new Panel();
first.setLayout(new GridLayout(4, 2));
first.add(new Label("User ID:"));
first.add(usidtxt);
first.add(new Label("Video ID:"));
first.add(vidtxt);
first.add(new Label("Genuineness:"));
first.add(gentxt);


Panel second = new Panel(new GridLayout(4, 1));
second.add(dltvibtn);

Panel third = new Panel();
third.add(errtxt);

add(first);
add(second);
add(third);
   
setTitle("DELETE VIEW");
setSize(450, 600);
setLayout(new FlowLayout());
setVisible(true);

}





private void displaySQLErrors(SQLException e)
{
errtxt.append("\nSQLException: " + e.getMessage() + "\n");
errtxt.append("SQLState:     " + e.getSQLState() + "\n");
errtxt.append("VendorError:  " + e.getErrorCode() + "\n");
}



public static void main(String[] args)
{
DeleteView delv = new DeleteView();

delv.addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
System.exit(0);
 }
});

delv.buildGUI();
}
}